import { ApiClient } from '@mondaydotcomorg/api';
import { GetColumnValueQuery, GetColumnValueQueryVariables } from "../generated/graphql";
import { getColumnValueQuery } from "../queries.graphql";

class MondayService {

    // ==========================================
    // 🚀 RAW HTTP FETCHER
    // ==========================================
    static async rawMondayQuery(token: string, query: string, variables: any = {}) {
        const response = await fetch("https://api.monday.com/v2", {
            method: 'POST',
            headers: {
                'Authorization': token,
                'Content-Type': 'application/json',
                'API-Version': '2023-10' 
            },
            body: JSON.stringify({ query, variables })
        });
        
        const data = await response.json();
        if (data.errors) {
            console.error("\n❌ RAW MONDAY API ERROR:");
            console.error(JSON.stringify(data.errors, null, 2));
            throw new Error(data.errors[0].message);
        }
        return data;
    }

    // ==========================================
    // 📦 RESTORED LEGACY FUNCTIONS 
    // ==========================================
    static async getMe(shortLiveToken: string) {
        try {
            const mondayClient = new ApiClient({ token: shortLiveToken });
            return await mondayClient.operations.getMeOp();
        } catch (err) { console.error("❌ Monday Service Error (getMe):", err); }
    }

    static async getColumnValue(token: string, itemId: string | number, columnId: string) {
        try {
            const mondayClient = new ApiClient({ token: token });
            const params: GetColumnValueQueryVariables = { itemId: [itemId.toString()], columnId: [columnId] };
            const response: GetColumnValueQuery = await mondayClient.request<GetColumnValueQuery>(getColumnValueQuery, params);
            return response?.items?.[0]?.column_values?.[0]?.value;
        } catch (err) { console.error("❌ Monday Service Error (getColumnValue):", err); }
    }

    // 👉 FIX: Uses raw fetch to prevent the SDK from silently dropping incoming messages!
    static async changeColumnValue(token: string, boardId: string | number, itemId: string | number, columnId: string, value: any) {
        try {
            const query = `
                mutation($boardId: ID!, $itemId: ID!, $columnId: String!, $value: JSON!) {
                    change_column_value(board_id: $boardId, item_id: $itemId, column_id: $columnId, value: $value) { id }
                }
            `;
            await this.rawMondayQuery(token, query, {
                boardId: String(boardId),
                itemId: String(itemId),
                columnId: columnId,
                value: JSON.stringify(value)
            });
        } catch (err) {
            console.error(`❌ changeColumnValue Error for Col ${columnId}:`, err);
        }
    }

    static async getSmartItemData(token: string, itemId: number | string) {
        try {
            const mondayClient = new ApiClient({ token: token });
            const query = `query ($itemId: [ID!]) { items(ids: $itemId) { board { id } assets { id public_url name } column_values { id column { title } text value ... on FormulaValue { display_value } ... on BoardRelationValue { display_value } ... on MirrorValue { display_value } } parent_item { id assets { id public_url name } column_values { id column { title } text value ... on FormulaValue { display_value } ... on BoardRelationValue { display_value } ... on MirrorValue { display_value } } } } }`;
            const response: any = await mondayClient.request(query, { itemId: [itemId.toString()] });
            return response?.items?.[0]; 
        } catch (err) { return null; }
    }


    // ==========================================
    // 💬 CHAT WIDGET FUNCTIONS
    // ==========================================

    static async getBoardColumns(token: string, boardId: number | string) {
        try {
            const query = `query { boards(ids: [${boardId}]) { columns { id title type } } }`;
            const result = await this.rawMondayQuery(token, query);
            return result.data?.boards?.[0]?.columns;
        } catch (err) { return null; }
    }

    /**
     * UI FETCH: Now reads the Row Name to know if the bubble goes left or right!
     */
    static async getChatLogsByPhone(token: string, archiveBoardId: string, phone: string) {
        try {
            const columns = await this.getBoardColumns(token, archiveBoardId);
            if (!columns) return [];

            const phoneColId = columns.find((c: any) => c.title.toLowerCase().includes('phone') || c.title.toLowerCase().includes('whatsapp'))?.id;
            const textColId = columns.find((c: any) => c.title.toLowerCase().includes('message') || c.title.toLowerCase().includes('text'))?.id;

            if (!phoneColId || !textColId) return [];

            // 👉 FIX: Added "name" to the query so we can read the row title!
            const query = `
                query {
                    items_page_by_column_values(board_id: ${archiveBoardId}, columns: [{column_id: "${phoneColId}", column_values: ["${phone}"]}]) {
                        items {
                            name
                            column_values { id text }
                        }
                    }
                }
            `;
            
            const result = await this.rawMondayQuery(token, query);
            const items = result.data?.items_page_by_column_values?.items || [];
            
            return items.map((item: any) => {
                const text = item.column_values.find((c: any) => c.id === textColId)?.text;
                
                // 👉 FIX: If the row is named "Message to...", mark it as 'agent' so it turns green!
                const isAgent = item.name && item.name.toLowerCase().includes('to');
                return { text, sender: isAgent ? 'agent' : 'customer' }; 
            });
        } catch (err) {
            console.error("❌ getChatLogsByPhone FAILED:", err);
            return [];
        }
    }

    /**
     * WEBHOOK LOGGING: Now names the row "Message TO" or "Message FROM"
     */
    static async createChatLog(token: string, boardId: string, data: { phone: string; text: string; sender: string; wamid?: string }) {
        try {
            console.log("\n=== 📝 PREPARING SINGLE-SHOT CHAT LOG ===");
            const columns = await this.getBoardColumns(token, boardId);
            if (!columns) throw new Error("Could not fetch Archive Board columns");

            const phoneCol = columns.find((c: any) => c.title.toLowerCase().includes('phone') || c.title.toLowerCase().includes('whatsapp'));
            const textCol = columns.find((c: any) => c.title.toLowerCase().includes('message') || c.title.toLowerCase().includes('text'));
            const wamidCol = columns.find((c: any) => c.title.toLowerCase().includes('id') || c.title.toLowerCase().includes('wamid'));

            const direction = data.sender === 'agent' ? 'to' : 'from';
            const itemName = `Message ${direction} ${data.phone}`;

            // Package all columns into a single JSON object
            let colVals: any = {};

            if (textCol) {
                // Safely handles both 'text' and 'long_text' column types
                colVals[textCol.id] = textCol.type === 'long_text' ? { text: data.text } : data.text;
            }
            
            if (phoneCol) {
                // Smartly detects country code to prevent Meta rejection
                colVals[phoneCol.id] = phoneCol.type === 'phone' 
                    ? { phone: data.phone, countryShortName: data.phone.startsWith('91') ? "IN" : "US" } 
                    : data.phone;
            }

            if (wamidCol && data.wamid) {
                colVals[wamidCol.id] = data.wamid;
            }

            // ONE single powerful query to do it all at once!
            const query = `
                mutation($boardId: ID!, $itemName: String!, $colVals: JSON!) {
                    create_item(board_id: $boardId, item_name: $itemName, column_values: $colVals) { 
                        id 
                    }
                }
            `;

            const variables = {
                boardId: String(boardId),
                itemName: itemName,
                colVals: JSON.stringify(colVals) // Safely inject the packaged data
            };

            const result = await this.rawMondayQuery(token, query, variables);
            console.log("✅ Single-shot injection successful! Row ID:", result.data?.create_item?.id);
            
            return result.data?.create_item?.id;

        } catch (error: any) {
            console.error("❌ createChatLog CRASHED!", error);
            throw error;
        }
    }
}

export default MondayService;