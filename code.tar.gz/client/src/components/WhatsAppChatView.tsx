import React, { useState, useEffect } from 'react';
import mondaySdk from 'monday-sdk-js';
import './WhatsAppChatView.css'; // Assuming you have some basic styles here

const monday = mondaySdk();

const WhatsAppChatView = () => {
    const [itemId, setItemId] = useState<string | null>(null);
    const [phoneNumber, setPhoneNumber] = useState<string | null>(null);
    const [messages, setMessages] = useState<any[]>([]);
    const [newMessage, setNewMessage] = useState("");
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        // 1. Listen for which item the user clicked on
        monday.listen("context", async (res: any) => {
            const currentItemId = res.data.itemId;
            setItemId(currentItemId);
            
            // 2. Fetch the actual phone number from this specific item
            fetchItemPhoneNumber(currentItemId);
        });
    }, []);

    const fetchItemPhoneNumber = async (id: string) => {
        setLoading(true);
        try {
            // NEW API COMPLIANT QUERY: We ask the board for the column titles, and the item for the text!
            const query = `
                query { 
                    items(ids: [${id}]) { 
                        board {
                            columns {
                                id
                                title
                            }
                        }
                        column_values { 
                            id 
                            text 
                        } 
                    } 
                }
            `;
            
            const response: any = await monday.api(query);
            
            if (response.errors) {
                console.error("❌ Monday API Error:", response.errors);
                setLoading(false);
                return;
            }

            const item = response.data.items[0];
            const boardColumns = item.board.columns;
            const itemColumnValues = item.column_values;

            // 1. Find the exact Column ID by searching the Board's Column Titles
            const phoneColumnDef = boardColumns.find((c: any) => {
                const title = c.title.toLowerCase();
                return title.includes('phone') || title.includes('mobile') || title.includes('whatsapp');
            });
            
            console.log("📞 [DEBUG] Found Column Definition by Title:", phoneColumnDef);

            let rawPhone = "";

            // 2. Use that exact ID to grab the text from the Item's Column Values
            if (phoneColumnDef) {
                const phoneColValue = itemColumnValues.find((val: any) => val.id === phoneColumnDef.id);
                rawPhone = phoneColValue?.text || "";
            }

            const cleanPhone = rawPhone.replace(/[^0-9]/g, '');
            console.log("🧼 [DEBUG] Cleaned Phone Number:", cleanPhone);

            if (cleanPhone && cleanPhone.length >= 10) {
                setPhoneNumber(cleanPhone);
                fetchChatHistory(cleanPhone); // Calls the backend with the phone number
            } else {
                setPhoneNumber(null);
                setLoading(false);
            }
        } catch (error) {
            console.error("❌ Error fetching phone number:", error);
            setLoading(false);
        }
    };

    const fetchChatHistory = async (phoneNumber: string) => {
        try {
            const session = await monday.get("sessionToken");
            
            const response = await fetch(`/api/monday/get_chat_history?phone=${phoneNumber}`, {
                method: "GET",
                headers: {
                    "Authorization": `Bearer ${session.data}`,
                    "Content-Type": "application/json"
                }
            });

            if (!response.ok) {
                const errorText = await response.text();
                console.error("❌ Backend rejected the request:", errorText);
                setLoading(false); // Turn off spinner if it fails
                return;
            }

            const data = await response.json();
            console.log("📥 Successfully fetched history:", data);
            
            // ==========================================
            // THE FIX: SAVE DATA AND STOP THE SPINNER
            // ==========================================
            if (data.messages) {
                setMessages(data.messages); // Put the messages into the UI
            } else {
                setMessages([]); // Fallback to empty if no messages exist yet
            }
            
            setLoading(false); // Turn off the loading screen!
            
        } catch (error) {
            console.error("❌ Frontend Network Error:", error);
            setLoading(false); // Turn off spinner if network crashes
        }
    };

    const handleSend = async () => {
        if (!newMessage.trim() || !phoneNumber) return;

        // Optimistically add to UI instantly so it feels fast to the user
        const tempMsg = { text: newMessage, sender: 'agent' };
        setMessages((prev) => [...prev, tempMsg]);
        
        // Save the text before clearing the input box
        const textToSend = newMessage;
        setNewMessage("");

        try {
            // 1. Grab the secure token
            const tokenRes = await monday.get("sessionToken");
            
            // 2. Send the real request to your backend
            await fetch('/api/monday/send_item_view_message', { 
                method: 'POST', 
                headers: {
                    'Authorization': tokenRes.data,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ phone: phoneNumber, message: textToSend }) 
            });

            // Optional: trigger success confetti in Monday!
            await monday.execute('valueCreatedForUser'); 
        } catch (error) {
            console.error("Failed to send message:", error);
            // In a production app, you could add logic here to remove the optimistic message if it fails
        }
    };

    if (loading) return <div className="p-4 text-center">Loading chat...</div>;

    return (
        <div className="whatsapp-container" style={{ display: 'flex', flexDirection: 'column', height: '100vh', backgroundColor: '#e5ddd5' }}>
            
            {/* ⚠️ SMART WARNING: If there is no phone number */}
            {!phoneNumber && (
                <div style={{ backgroundColor: '#ffcc00', padding: '10px', textAlign: 'center', fontWeight: 'bold' }}>
                    ⚠️ Cannot send messages: This contact is missing a valid phone number.
                </div>
            )}

            {/* Chat History Area */}
            <div className="chat-history" style={{ flex: 1, padding: '20px', overflowY: 'auto' }}>
                {messages.map((msg, index) => (
                    <div key={index} style={{ 
                        textAlign: msg.sender === 'agent' ? 'right' : 'left',
                        margin: '10px 0'
                    }}>
                        <span style={{
                            backgroundColor: msg.sender === 'agent' ? '#dcf8c6' : '#ffffff',
                            padding: '10px 15px',
                            borderRadius: '10px',
                            display: 'inline-block',
                            maxWidth: '70%'
                        }}>
                            {msg.text}
                        </span>
                    </div>
                ))}
                {messages.length === 0 && phoneNumber && (
                    <p style={{ textAlign: 'center', color: '#888' }}>No chat history found for {phoneNumber}. Say hi!</p>
                )}
            </div>

            {/* Input Area */}
            <div className="chat-input" style={{ padding: '10px', backgroundColor: '#f0f0f0', display: 'flex' }}>
                <input 
                    type="text" 
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    placeholder={phoneNumber ? "Type a message..." : "No phone number available"}
                    disabled={!phoneNumber} // Locks input if no number!
                    style={{ flex: 1, padding: '10px', borderRadius: '20px', border: '1px solid #ccc' }}
                    onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                />
                <button 
                    onClick={handleSend} 
                    disabled={!phoneNumber} // Locks button if no number!
                    style={{ marginLeft: '10px', padding: '10px 20px', borderRadius: '20px', backgroundColor: phoneNumber ? '#25d366' : '#ccc', color: 'white', border: 'none', cursor: phoneNumber ? 'pointer' : 'not-allowed' }}
                >
                    Send
                </button>
            </div>
        </div>
    );
};

export default WhatsAppChatView;