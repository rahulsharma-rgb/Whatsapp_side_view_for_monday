import React, { useEffect, useState } from "react";
import "./App.css";
// @ts-ignore
import "@vibe/core/tokens";
import mondaySdk from "monday-sdk-js";
import NewApp from "./components/NewApp/NewApp";
import WhatsAppChatView from "./components/WhatsAppChatView";

const monday = mondaySdk();

const App = () => {
    // 1. Start with a 'loading' state so we don't accidentally show the wrong app!
    const [viewType, setViewType] = useState<string>("loading");

    useEffect(() => {
        monday.listen("context", (res: any) => {
            console.log("🔍 Monday Context Loaded:", res.data);
            
            // 2. Monday has updated their SDK a few times. This safely catches the view type 
            // whether it's coming from viewMode, viewType, or appFeature.type
            const type = res.data.viewMode || res.data.viewType || res.data.appFeature?.type || "unknown";
            
            setViewType(type); 
        });
    }, []);

    // Show a blank screen or spinner for the first split second while waiting for Monday
    if (viewType === "loading") {
        return <div style={{ padding: '20px', textAlign: 'center' }}>Loading App...</div>;
    }

    // 3. Check for all the ways Monday identifies an Item View
    if (viewType === "item_view" || viewType === "ItemView" || viewType === "AppFeatureItemView") {
        return (
            <div className="App">
                <WhatsAppChatView />
            </div>
        );
    }

    // 4. If it's a Board View (or anything else), show your original NewApp
    return (
        <div className="App">
            <NewApp />
        </div>
    );
};

export default App;