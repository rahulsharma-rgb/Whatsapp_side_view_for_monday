import React, { useState, useEffect } from 'react';
import mondaySdk from 'monday-sdk-js';
import './WhatsAppChatView.css'; // Assuming you have some basic styles here

const monday = mondaySdk();

const WhatsAppChatView = () => {
    const [itemId, setItemId] = useState<string | null>(null);
    const [phoneNumber, setPhoneNumber] = useState<string | null>(null);
    const [messages, setMessages] = useState<any[]>([]);
    const [newMessage, setNewMessage] = useState("");
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        // 1. Listen for which item the user clicked on
        monday.listen("context", async (res: any) => {
            const currentItemId = res.data.itemId;
            setItemId(currentItemId);
            
            // 2. Fetch the actual phone number from this specific item
            fetchItemPhoneNumber(currentItemId);
        });
    }, []);

    const fetchItemPhoneNumber = async (id: string) => {
        setLoading(true);
        try {
            const query = `query { items (ids: [${id}]) { column_values { id type text value } } }`;
            const response = await monday.api(query);
            const columns = response.data.items[0].column_values;
            
            // Find the phone column
            const phoneCol = columns.find((c: any) => c.type === 'phone' || c.id.toLowerCase().includes('phone'));
            
            if (phoneCol && phoneCol.text) {
                // Clean the phone number (remove spaces, +, etc)
                const cleanPhone = phoneCol.text.replace(/[^0-9]/g, '');
                setPhoneNumber(cleanPhone);
                
                // 3. Now that we have the universal phone number, fetch the chat history!
                fetchChatHistory(cleanPhone);
            } else {
                setPhoneNumber(null);
                setLoading(false);
            }
        } catch (error) {
            console.error("Error fetching phone number:", error);
            setLoading(false);
        }
    };

    const fetchChatHistory = async (phone: string) => {
        try {
            // 1. Grab the secure token from Monday
            const tokenRes = await monday.get("sessionToken");
            
            // 2. Fetch from your actual backend route
            const res = await fetch(`/api/monday/get_chat_history?phone=${phone}`, {
                headers: {
                    'Authorization': tokenRes.data,
                    'Content-Type': 'application/json'
                }
            });
            
            const data = await res.json();
            
            if (data.messages) {
                // Reverse the array so the newest messages appear at the bottom of the chat UI
                setMessages(data.messages.reverse()); 
            }
            
            setLoading(false);
        } catch (error) {
            console.error("Failed to load history", error);
            setLoading(false);
        }
    };

    const handleSend = async () => {
        if (!newMessage.trim() || !phoneNumber) return;

        // Optimistically add to UI instantly so it feels fast to the user
        const tempMsg = { text: newMessage, sender: 'agent' };
        setMessages((prev) => [...prev, tempMsg]);
        
        // Save the text before clearing the input box
        const textToSend = newMessage;
        setNewMessage("");

        try {
            // 1. Grab the secure token
            const tokenRes = await monday.get("sessionToken");
            
            // 2. Send the real request to your backend
            await fetch('/api/monday/send_item_view_message', { 
                method: 'POST', 
                headers: {
                    'Authorization': tokenRes.data,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ phone: phoneNumber, message: textToSend }) 
            });

            // Optional: trigger success confetti in Monday!
            await monday.execute('valueCreatedForUser'); 
        } catch (error) {
            console.error("Failed to send message:", error);
            // In a production app, you could add logic here to remove the optimistic message if it fails
        }
    };

    if (loading) return <div className="p-4 text-center">Loading chat...</div>;

    return (
        <div className="whatsapp-container" style={{ display: 'flex', flexDirection: 'column', height: '100vh', backgroundColor: '#e5ddd5' }}>
            
            {/* ⚠️ SMART WARNING: If there is no phone number */}
            {!phoneNumber && (
                <div style={{ backgroundColor: '#ffcc00', padding: '10px', textAlign: 'center', fontWeight: 'bold' }}>
                    ⚠️ Cannot send messages: This contact is missing a valid phone number.
                </div>
            )}

            {/* Chat History Area */}
            <div className="chat-history" style={{ flex: 1, padding: '20px', overflowY: 'auto' }}>
                {messages.map((msg, index) => (
                    <div key={index} style={{ 
                        textAlign: msg.sender === 'agent' ? 'right' : 'left',
                        margin: '10px 0'
                    }}>
                        <span style={{
                            backgroundColor: msg.sender === 'agent' ? '#dcf8c6' : '#ffffff',
                            padding: '10px 15px',
                            borderRadius: '10px',
                            display: 'inline-block',
                            maxWidth: '70%'
                        }}>
                            {msg.text}
                        </span>
                    </div>
                ))}
                {messages.length === 0 && phoneNumber && (
                    <p style={{ textAlign: 'center', color: '#888' }}>No chat history found for {phoneNumber}. Say hi!</p>
                )}
            </div>

            {/* Input Area */}
            <div className="chat-input" style={{ padding: '10px', backgroundColor: '#f0f0f0', display: 'flex' }}>
                <input 
                    type="text" 
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    placeholder={phoneNumber ? "Type a message..." : "No phone number available"}
                    disabled={!phoneNumber} // Locks input if no number!
                    style={{ flex: 1, padding: '10px', borderRadius: '20px', border: '1px solid #ccc' }}
                    onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                />
                <button 
                    onClick={handleSend} 
                    disabled={!phoneNumber} // Locks button if no number!
                    style={{ marginLeft: '10px', padding: '10px 20px', borderRadius: '20px', backgroundColor: phoneNumber ? '#25d366' : '#ccc', color: 'white', border: 'none', cursor: phoneNumber ? 'pointer' : 'not-allowed' }}
                >
                    Send
                </button>
            </div>
        </div>
    );
};

export default WhatsAppChatView;