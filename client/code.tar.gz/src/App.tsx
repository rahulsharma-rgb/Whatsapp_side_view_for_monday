// File: client/src/App.tsx

import React, { useEffect, useState } from "react";
import "./App.css";
// @ts-ignore
import "@vibe/core/tokens";
import mondaySdk from "monday-sdk-js";
import NewApp from "./components/NewApp/NewApp";
import WhatsAppChatView from "./components/WhatsAppChatView";

const monday = mondaySdk();

const App = () => {
    const [viewType, setViewType] = useState<string>("");

    useEffect(() => {
        monday.listen("context", (res: any) => {
            setViewType(res.data.viewType); 
        });
    }, []);

    return (
        <div className="App">
            {viewType === "item_view" ? (
                <WhatsAppChatView />
            ) : (
                <NewApp />
            )}
        </div>
    );
};

export default App;